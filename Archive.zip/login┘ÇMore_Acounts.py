import requests
import json 
from time import sleep , time
import random
from data import data_all

All = []
Error = []

baner = """
            _               _   _             _        
           | |             (_) | |           (_)       
  ___  __ _| | ____ _ _ __  _  | | ___   __ _ _ _ __   
 / __|/ _` | |/ / _` | '_ \| | | |/ _ \ / _` | | '_ \  
 \__ \ (_| |   < (_| | | | | | | | (_) | (_| | | | | | 
 |___/\__,_|_|\_\__,_|_| |_|_| |_|\___/ \__, |_|_| |_| 
                                         __/ |         
                                        |___/          
                                            """
print(baner)




def login(national_id_number,password):

    try :

        session = requests.session()
        # session.proxies = {
        #             "http": "socks5://kfluwqld-SA-rotate:e3p2uyjp2bgh@p.webshare.io:80/",
        #             "https": "socks5://kfluwqld-SA-rotate:e3p2uyjp2bgh@p.webshare.io:80/"}

            
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,ar-SA;q=0.8,ar;q=0.7',
            'content-type': 'application/x-protobuffer',
            # 'cookie': '__Secure-3PAPISID=hvOSYeCCdP4JlmnR/Abevs1VLuiwBRJz-6; __Secure-3PSID=g.a000jgj9Em9o-ERcDGUeDX7aXjn3LSSvUYB5-LgWig2WUAL3VYB183yuoHYpQ8f9H9uP8pQNDgACgYKAb0SAQASFQHGX2MiTiBtsv_rdkTnUfG2a-AsARoVAUF8yKrZT4DiTuXeWM3TLVNkW57Q0076; NID=514=AY775A7n0KhRviWMBuOvudTu1ZHOjQcbYOF16B2mYp7FPmXPjQBP4fzxoW6qUHOedGy3lzTfiKWegwq-N5vlvzqR26rch4Ykw_asRye5AbEHFLt62B9-DzlqJD8MVSKmQPFvlJYdiaumPmyrJhc69koCqFdDMj-q6VkxCqV2agk9TyPO3tK33T0r24RrDWtumBzJGXkD22NNj1uidWI_XW_m0jhfi1v3VHabBDglXPUu2bX_co0ZydP6UUvNPuWWxqyXPD_xfX5c_BA_DiEXxjmOor3w6bNwlygRuyyuOLcOuEtPvA; 1P_JAR=2024-05-22-06; __Secure-3PSIDTS=sidts-CjIBLwcBXIWrH3ul4BXmA-B0JM2hoPEH_lg4pjLDbRRPzYUSmNLw67ZStsk8FI00bCSZihAA; __Secure-3PSIDCC=AKEyXzUOAkuXOZKvZt6xX0eWx88HloVmhp8KrOOZ6YHQph-0AwPw1tMbvnoVKWYo8NEHwbrtTWc',
            'origin': 'https://www.google.com',
            'priority': 'u=1, i',
            'referer': 'https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lfc1sspAAAAAFBZyNk54DwbeKgHAGg_xOT48Bkm&co=aHR0cHM6Ly9zYWthbmkuc2E6NDQz&hl=ar&v=8k85QBI-qzxmenDv318AZH30&size=invisible&cb=1zvxtoh6wk4n',
            'sec-ch-ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-client-data': 'CLG1yQEIkrbJAQiitskBCKmdygEI7trKAQiSocsBCPWYzQEIhqDNAQjIhc4B',
        }

        params = {
            'k': '6Lfc1sspAAAAAFBZyNk54DwbeKgHAGg_xOT48Bkm',
        }

        data = random.choice(data_all)

        response = requests.post('https://www.google.com/recaptcha/api2/reload', params=params, headers=headers, data=data)


        print(response.text.split('"')[3])

       




        headers = {
            'accept': 'application/json',
            'accept-language': 'ar',
            'app-locale': 'ar',
            'content-type': 'application/json',
            # 'cookie': '_gcl_au=1.1.1909840314.1713877663; _ga=GA1.1.1070927391.1713877664; _hjSessionUser_3667620=eyJpZCI6ImRjYWExMGYxLWQ5MjYtNTYyYy04MGEzLTdlZTQ4ZDBlNTBkZCIsImNyZWF0ZWQiOjE3MTM4Nzc2NjQ3NjMsImV4aXN0aW5nIjp0cnVlfQ==; steam-locale=ar; _ga_ZB3N5KQMRL=GS1.1.1716393460.11.1.1716393460.0.0.0; _hjSession_3667620=eyJpZCI6ImY4YjUzMTUwLTk5MDktNGM3Zi1iNGUxLTZiMThlMzMwYzMxMCIsImMiOjE3MTYzOTM0NjExNjEsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=; _ga_L991W0X9QC=GS1.1.1716393462.12.0.1716394007.0.0.0',
            'origin': 'https://sakani.sa',
            'priority': 'u=1, i',
            'referer': 'https://sakani.sa/app/authentication/login',
            'sec-ch-ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        }

        json_data = {
            'data': {
                'attributes': {
                    'action': 'beneficiary_login',
                    'identifier': national_id_number,
                    'recaptcha_challenge': response.text.split('"')[3],
                    'recaptcha_type': 'grecaptchaV3',
                    'site_key': '6Lfc1sspAAAAAFBZyNk54DwbeKgHAGg_xOT48Bkm',
                },
            },
        }


        response = session.post('https://sakani.sa/captchaApi/grecaptcha/validate', headers=headers, json=json_data , timeout=10)
        print(response.text)

        recaptcha_auth_token  = response.json()["data"]["attributes"]["recaptcha_auth_token"]



        print(recaptcha_auth_token)
        print("="*200)



      

        json_data = {'data': {'id': 'beneficiary_sessions','attributes': {'national_id_number': national_id_number,'password': password,},},'recaptcha_auth_token': recaptcha_auth_token,}

        response = session.post('https://sakani.sa/authApi/api/v4/beneficiary_session',  headers=headers, json=json_data)
        print(response.json())
        national_id_number2222 = response.json()["data"]["attributes"]["national_id_number"]
        print(national_id_number2222)

        print("="*200)


        def clear_old_otb():
                requests.get("https://165.227.171.137/clear_otp" , verify=False)
        clear_old_otb()

        json_data = {
            'data': {'attributes': {'user_identity_number': national_id_number ,'user_type': 'beneficiary','otp_action': 'beneficiary_login',},},'recaptcha_auth_token':recaptcha_auth_token,}

        response = session.post('https://sakani.sa/authApi/api/v4/otp/request', headers=headers, json=json_data)


        def get_otp():
                return requests.get("https://165.227.171.137/sms" , verify=False).json()["otp"]


        OTB = get_otp()
        
        counter = 0
        
        while OTB == None and counter <  30 :
                    OTB = get_otp()
                    print(f"The code {OTB} has been successfully retrieved from the phone ")
                    
                    
                    counter += 1

        print(OTB)

        print(response.json()["data"]["id"])


        json_data = {'data': {'attributes': {'user_identity_number': national_id_number,'otp':OTB,'id': response.json()["data"]["id"],},},'recaptcha_auth_token': recaptcha_auth_token,}

        response = session.post('https://sakani.sa/authApi/api/v4/otp/validate', headers=headers, json=json_data)


        json_data = {'data':{'attributes':{'national_id_number':national_id_number,'password':password,'otp_uuid':response.json()["data"]["id"],},},}
        response = session.post('https://sakani.sa/authApi/api/v4/beneficiary_session/login',headers=headers,json=json_data)
        AUTHCODE = response.json()["data"]["attributes"]["token"]

        print(session.cookies.get_dict())
        # print(AUTHCODE)

        All.append(national_id_number+":"+national_id_number2222+":"+AUTHCODE+"\n")
        v = session.get("https://sakani.sa/app/user-profile/dashboard/overview")
        
        print(session.cookies.get_dict())


    except Exception as er :
           print(er)
           Error.append(national_id_number+":"+password+"\n")







for i in open("credentials.txt").readlines():
        
        national_id_number = i.strip().split(":")[0]
        password = i.strip().split(":")[1]
        print(national_id_number)
        print(password)
        login(national_id_number , password)
        # sleep(3)

    
    


# Write All Acounts login
        
with open("AuthCode.txt" ,"a") as file :
        file.writelines(All)


# Write All Not login ! 
with open("User_Not_Login" ,"w") as file :
        file.writelines(Error)




